



<?php
session_start();
include_once "config.php";
$connection = mysqli_connect( DB_HOST, DB_USER, DB_PASSWORD, DB_NAME );
if ( !$connection ) {
    echo mysqli_error( $connection );
    throw new Exception( "Database cannot Connect" );
} else {
    $action = $_REQUEST['action'] ?? '';

    if ( 'addfaculty' == $action ) {
        $website = $_REQUEST['website'] ?? '';
        $phone = $_REQUEST['phone'] ?? '';
        $phone = str_replace(',', '<br/>', $phone);
        $declaration = $_REQUEST['declaration'] ?? '';
        $declaration = str_replace(',', '<br/>', $declaration);
        $departments = $_REQUEST['departments'] ?? '';
        $departments = str_replace(',', '<br/>', $departments);
        

        if ( $website && $phone && $declaration&& $departments) 
        {
            $query = "INSERT INTO facultys(website,phone,declaration,departments) VALUES ('$website','$phone','$declaration','$departments')";
            mysqli_query( $connection, $query );
            header( "location:adminn.php?id=allfaculty" );
        }

    } elseif ( 'updatefaculty' == $action ) {
        $website = $_REQUEST['website'] ?? '';
        $phone = $_REQUEST['phone'] ?? '';
        $phone = str_replace(',', '<br/>', $phone);
        $declaration = $_REQUEST['declaration'] ?? '';
        $declaration = str_replace(',', '<br/>', $declaration);
        $departments = $_REQUEST['departments'] ?? '';
        $departments = str_replace(',', '<br/>', $departments);
        

        if ( $website && $phone && $declaration && $departments) 
        {
            $query = "UPDATE facultys SET website='$website', phone='$phone', declaration= '$declaration', departments= '$departments' WHERE id='{$id}'";
            mysqli_query( $connection, $query );
            header( "location:adminn.php?id=allfaculty" );
        }
    } elseif ( 'addprofessor' == $action ) {
        $fname = $_REQUEST['fname'] ?? '';        
        $email = $_REQUEST['email'] ?? '';
        $phone = $_REQUEST['phone'] ?? '';
        $phone = str_replace(',', '<br/>', $phone);
        $password = $_REQUEST['password'] ?? '';
        $Address = $_REQUEST['Address'] ?? '';
        $Subjects = $_REQUEST['Subjects'] ?? '';
        $Subjects = str_replace(',', '<br/>', $Subjects);
        $DepartmentName = $_REQUEST['DepartmentName'] ?? '';
        $DepartmentName = str_replace(',', '<br/>', $DepartmentName);
        
        

        if ( $fname && $email && $phone && $password && $Address && $Subjects && $DepartmentName) 
        {
            $query = "INSERT INTO professors(fname,email,phone,password,Address,Subjects,DepartmentName) VALUES ('{$fname}','$email','$phone','$password','$Address','$Subjects','$DepartmentName')";
            mysqli_query( $connection, $query );
            header( "location:adminn.php?id=allprofessor" );
        }
    } elseif ( 'updateprofessor' == $action ) {
        $id = $_REQUEST['id'] ?? '';
        $fname = $_REQUEST['fname'] ?? '';
        $email = $_REQUEST['email'] ?? '';
        $oldPassword = $_REQUEST['oldPassword'] ?? '';
        $newPassword = $_REQUEST['newPassword'] ?? '';
        $phone = $_REQUEST['phone'] ?? '';
        $phone = str_replace(',', '<br/>', $phone);
        $Address = $_REQUEST['Address'] ?? '';
        $Subjects = $_REQUEST['Subjects'] ?? '';
        $Subjects = str_replace(',', '<br/>', $Subjects);
        $DepartmentName = $_REQUEST['DepartmentName'] ?? '';
        $DepartmentName = str_replace(',', '<br/>', $DepartmentName);
        
        if ( $fname && $email && $phone && $oldPassword && $newPassword && $Address && $Subjects && $DepartmentName) 
        {
            
           $query = "UPDATE professors SET fname='{$fname}', email='$email', phone='$phone', password='{$newPassword}', Address='$Address', Subjects='$Subjects',DepartmentName='$DepartmentName' WHERE id='{$id}'";
            mysqli_query( $connection, $query );
            header( "location:adminn.php?id=allprofessor" );
        
        }
    } 
    elseif ( 'addstudent' == $action ) 
    {
        $fname = $_REQUEST['fname'] ?? '';
        $email = $_REQUEST['email'] ?? '';
        $phone = $_REQUEST['phone'] ?? '';
        $phone = str_replace(',', '<br/>', $phone);
        $password = $_REQUEST['password'] ?? '';
        $DepartmentName = $_REQUEST['DepartmentName'] ?? '';
        $levelnumber = $_REQUEST['levelnumber'] ?? '';
        $CGPA = $_REQUEST['CGPA'] ?? '';

        if ( $fname && $email && $phone && $password && $DepartmentName && $levelnumber && $CGPA)  
        {
            $query = "INSERT INTO students(fname,email,phone,password,DepartmentName,levelnumber,CGPA) VALUES ('{$fname}','$email','$phone','$password','$DepartmentName','$levelnumber','$CGPA')";
            mysqli_query( $connection, $query );
            header( "location:adminn.php?id=allstudent" );
        }
    } 
    elseif ( 'updateadmin' == $action ) {
        $id = $_REQUEST['id'] ?? '';
        $fname = $_REQUEST['fname'] ?? '';
        $email = $_REQUEST['email'] ?? '';
        $oldPassword = $_REQUEST['oldPassword'] ?? '';
        $newPassword = $_REQUEST['newPassword'] ?? '';
        $phone = $_REQUEST['phone'] ?? '';
        $phone = str_replace(',', '<br/>', $phone);
        

        if ( $fname && $email && $oldPassword && $newPassword && $phone) 
        {            
           $query = "UPDATE admins SET fname='{$fname}', email='$email', password='{$newPassword}', phone='$phone', WHERE id='{$id}'";
            mysqli_query( $connection, $query );
            header( "location:adminn.php" );
                    
        }
    }
    elseif ( 'updatestudent' == $action ) 
    {
        $id = $_REQUEST['id'] ?? '';
        $fname = $_REQUEST['fname'] ?? '';
        $email = $_REQUEST['email'] ?? '';
        $oldPassword = $_REQUEST['oldPassword'] ?? '';
        $newPassword = $_REQUEST['newPassword'] ?? '';
        $phone = $_REQUEST['phone'] ?? '';
        $phone = str_replace(',', '<br/>', $phone);
        $DepartmentName = $_REQUEST['DepartmentName'] ?? '';
        $levelnumber = $_REQUEST['levelnumber'] ?? '';
        $CGPA = $_REQUEST['CGPA'] ?? '';

        if ( $fname && $email && $oldPassword && $newPassword && $phone && $DepartmentName && $levelnumber && $CGPA) 
        {
            
            $query = "UPDATE students SET fname='{$fname}', email='$email', password='{$newPassword}', phone='$phone',DepartmentName='$DepartmentName',levelnumber='$levelnumber', CGPA='$CGPA' WHERE id='{$id}'";
            mysqli_query( $connection, $query );
            header( "location:adminn.php?id=allstudent" );
        
        }
    } 

    if ( 'adddepartmentt' == $action ) 
    {
        $name = $_REQUEST['name'] ?? '';
        $Abbreviation = $_REQUEST['Abbreviation'] ?? '';
        $Clarification = $_REQUEST['Clarification'] ?? '';
        $availablefacultys = $_REQUEST['availablefacultys'] ?? '';
        $availablefacultys = str_replace(',', '<br/>', $availablefacultys);

        if ( $name && $Abbreviation && $Clarification && $availablefacultys ) 
        {
            $query = "INSERT INTO departmentts(name,Abbreviation,Clarification,availablefacultys) VALUES ('{$name}','$Abbreviation','$Clarification','$availablefacultys')";
            mysqli_query( $connection, $query );
            header( "location:adminn.php?id=alldepartmentt" );
        }

    } 
    elseif ( 'updatedepartmentt' == $action ) 
    {
        $id = $_REQUEST['id'] ?? '';
        $name = $_REQUEST['name'] ?? '';
        $Abbreviation = $_REQUEST['Abbreviation'] ?? '';
        $Clarification = $_REQUEST['Clarification'] ?? '';
        $availablefacultys = $_REQUEST['availablefacultys'] ?? '';
        $availablefacultys = str_replace(',', '<br/>', $availablefacultys);
        

        if ( $name && $Abbreviation && $Clarification && $availablefacultys) 
        {
            $query = "UPDATE departmentts SET name='{$name}', Abbreviation='$Abbreviation',Clarification= '$Clarification' ,availablefacultys= '$availablefacultys' WHERE id='{$id}'";
            mysqli_query( $connection, $query );
            header( "location:adminn.php?id=alldepartmentt" );
        }
    }

        elseif ( 'contact' == $action ) 
        {
        $id = $_REQUEST['id'] ?? '';
        

        $conn = new PDO('mysql:host=localhost;dbname=mydatabase', 'root', '');

        $session_id = $_SESSION['id'];
        $session_query = $conn->query("select * from students where id = '$session_id'");
        $user_row = $session_query->fetch();
        $username = $user_row['fname']." ".$user_row['lname'];
        $avatar = $user_row['avatar'];

        $studentID = $_REQUEST['id'];
        $my_message  = $_POST['my_message'];
        $conn->query("insert into message(reciever_id,content,date_sended,sender_id) values('$studentID','$my_message',NOW(),'$session_id')");

        }
        elseif ( 'reqq' == $action ) 
    {
        $Name = $_REQUEST['Name'] ?? '';
        $Gmail = $_REQUEST['Gmail'] ?? '';
        $Phone = $_REQUEST['Phone'] ?? '';
        $Age = $_REQUEST['Age'] ?? '';
        $Address = $_REQUEST['Address'] ?? '';
        $Qualification = $_REQUEST['Qualification'] ?? '';
        $Subject = $_REQUEST['Subject'] ?? '';
        $faculty = $_REQUEST['faculty'] ?? '';
        $department = $_REQUEST['department'] ?? '';

        if ( $Name && $Gmail && $Phone && $Age && $Address && $Qualification && $Subject && $faculty && $department)
        {
            $query = "INSERT INTO req(Name , Gmail , Phone , Age , Address , Qualification , Subject , faculty , department) VALUES ('{$Name}','$Gmail','$Phone','$Age','$Address','$Qualification','$Subject','$faculty','$department')";
            mysqli_query( $connection, $query );
            header( "location:index.php" );
        }
    } 
        else 
        {
            echo mysqli_error( $connection );
        }



}
