-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 04, 2021 at 05:12 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydatabase`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` varchar(100) NOT NULL DEFAULT 'admin',
  `avatar` varchar(255) NOT NULL DEFAULT 'dpa.png'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `fname`, `lname`, `email`, `phone`, `password`, `role`, `avatar`) VALUES
(2, 'Admin', 'admin', 'admin@mail.com', '01221888866', '123', 'admin', 'dpa.png'),
(3, 'admin2', '', 'admin2@mail.com', '01221312688', '1234', 'admin', 'dpa.png');

-- --------------------------------------------------------

--
-- Table structure for table `degrees`
--

CREATE TABLE `degrees` (
  `id` int(11) NOT NULL,
  `Assegnments` varchar(255) NOT NULL,
  `Mid` varchar(255) DEFAULT NULL,
  `Oral` varchar(255) DEFAULT NULL,
  `Practical` varchar(255) DEFAULT NULL,
  `Final` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `degrees`
--

INSERT INTO `degrees` (`id`, `Assegnments`, `Mid`, `Oral`, `Practical`, `Final`) VALUES
(10, '5', '15', '8', '10', '60'),
(23, '4', '12', '7', '9', '55');

-- --------------------------------------------------------

--
-- Table structure for table `departmentts`
--

CREATE TABLE `departmentts` (
  `id` int(11) NOT NULL,
  `Clarification` varchar(255) DEFAULT NULL,
  `availablefacultys` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `Abbreviation` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `departmentts`
--

INSERT INTO `departmentts` (`id`, `Clarification`, `availablefacultys`, `name`, `Abbreviation`) VALUES
(33, 'deals with computer progams any anything belog to computer', '.Operating Systems<br/>.Software Construction<br/>.Software Analysis', 'Computer Science', 'CS'),
(34, 'deals with Networks', '.Computer Network<br/> .Computer Security', 'Information Technology', 'IT'),
(35, 'deals with development of software', '.Software Analysis<br/>.Open Source Software', 'Software Engineering', 'SE');

-- --------------------------------------------------------

--
-- Table structure for table `facultys`
--

CREATE TABLE `facultys` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `website` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `gp` varchar(100) NOT NULL,
  `role` varchar(100) NOT NULL DEFAULT 'faculty',
  `avatar` varchar(255) NOT NULL DEFAULT 'dpf.png',
  `departments` varchar(255) NOT NULL,
  `declaration` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `facultys`
--

INSERT INTO `facultys` (`id`, `name`, `location`, `website`, `phone`, `gp`, `role`, `avatar`, `departments`, `declaration`) VALUES
(61, '', '', 'https://www.facebook.com/FCDS1/', '1', '', 'faculty', 'dpf.png', '.Computer Network<br/> .Computer Security', 'Teaching Computer fundamentals and the start with Operating system'),
(62, '', '', 'https://www.facebook.com/FCDS2/', '2', '', 'faculty', 'dpf.png', '.Operating Systems<br/>.Software Construction<br/>.Software Analysis', 'Teaching Programming fundamentals and the start with code Written'),
(63, '', '', 'https://www.facebook.com/FCDS3/', '3', '', 'faculty', 'dpf.png', '.Software Analysis<br/>.Open Source Software', 'Teaching Gui Programming'),
(64, '', '', 'https://www.facebook.com/FCDS4/', '4', '', 'faculty', 'dpf.png', '.computer security', 'Teaching Advanced Programming Languages');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `message_id` int(11) NOT NULL,
  `stsender_id` int(11) DEFAULT NULL,
  `streciever_id` int(11) DEFAULT NULL,
  `content` varchar(100) NOT NULL,
  `date_sended` varchar(100) NOT NULL,
  `profsender_id` int(11) DEFAULT NULL,
  `profreciever_id` int(11) DEFAULT NULL,
  `thename` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `professors`
--

CREATE TABLE `professors` (
  `id` int(11) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` varchar(100) NOT NULL DEFAULT 'professor',
  `avatar` varchar(255) NOT NULL DEFAULT 'dpp.png',
  `FacultyName` varchar(255) DEFAULT NULL,
  `DepartmentName` varchar(255) DEFAULT NULL,
  `levelnumber` varchar(255) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `Subjects` varchar(255) DEFAULT NULL,
  `SubjectsCode` varchar(255) DEFAULT NULL,
  `chn` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `professors`
--

INSERT INTO `professors` (`id`, `fname`, `lname`, `email`, `phone`, `password`, `role`, `avatar`, `FacultyName`, `DepartmentName`, `levelnumber`, `Address`, `Subjects`, `SubjectsCode`, `chn`) VALUES
(21, 'Ahmed Ali', '', 'drahmed@mail.com', '01221873447', '123', 'professor', 'dpp.png', 'Computing and Information', 'Software Enginering', '3', 'Cleopatra, Sidi Gaber Street, Alexandria', '.Software Analysis<br/>.Open Source Software', 'SEN113', '3'),
(22, 'Ali Ahmed', '', 'drali@mail.com', '01154219853', '1234', 'professor', 'p1.png', 'Engineering', 'Computer Science', '3', 'Miami, 56th Street, Alexandria', 'Computer Network', 'ELE100', '2'),
(23, 'Eslam Muhammed', '', 'Eslam@mail.com', '01224567894', '2345678987654', 'professor', 'p3.png', 'Engineering', 'Information Technology', '3', 'Janaklis, Alexandria', 'Software Construction', 'GEO122', '3'),
(24, 'Hossam Adel', '', 'Hossam@mail.com', '01229875321', '123456787654', 'professor', 'p4.png', 'Computing and Information', 'Computer Science', '3', 'Abu Qir, Alexandria', 'Visual Programming', 'VPG133', '3');

-- --------------------------------------------------------

--
-- Table structure for table `req`
--

CREATE TABLE `req` (
  `id` int(11) NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `Gmail` varchar(255) DEFAULT NULL,
  `Phone` varchar(255) DEFAULT NULL,
  `Age` varchar(255) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `Qualification` varchar(255) DEFAULT NULL,
  `Subject` varchar(255) DEFAULT NULL,
  `faculty` varchar(255) DEFAULT NULL,
  `department` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `req`
--

INSERT INTO `req` (`id`, `Name`, `Gmail`, `Phone`, `Age`, `Address`, `Qualification`, `Subject`, `faculty`, `department`) VALUES
(5, 'Fahmy Ali', 'Fahmy123@gmail.com', '01235578896', '30', 'Shatby, Alexandria', 'PhD in Software Engineering', 'Software Evolution', 'Computing and Information', 'Software Engineering'),
(6, 'Yasser Marwan', 'YasserMarwan2299@gmail.com', '01221983769', '27', 'Al Ajmi, Alexandria', 'PhD in Robotics', 'Medical Robotics', 'Artificial Intelligence', 'Robotics');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` varchar(100) NOT NULL DEFAULT 'student',
  `avatar` varchar(255) NOT NULL DEFAULT 'dps.png',
  `FacultyName` varchar(255) DEFAULT NULL,
  `DepartmentName` varchar(255) DEFAULT NULL,
  `levelnumber` int(11) DEFAULT NULL,
  `CGPA` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `fname`, `lname`, `email`, `phone`, `password`, `role`, `avatar`, `FacultyName`, `DepartmentName`, `levelnumber`, `CGPA`) VALUES
(10, 'Ahmed Ali', '', 'ahmed@mail.com', '01221413226', '123', 'student', 'dps.png', 'Computing and Information', 'Software Enginering', 3, '3'),
(23, 'Ali Ahmed', '', 'ali@mail.com', '01000287643', '1234', 'student', 'st3.png', 'Engineering', 'Software Enginering', 3, '3.5');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `degrees`
--
ALTER TABLE `degrees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `departmentts`
--
ALTER TABLE `departmentts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `facultys`
--
ALTER TABLE `facultys`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`website`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`message_id`);

--
-- Indexes for table `professors`
--
ALTER TABLE `professors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `fname` (`fname`);

--
-- Indexes for table `req`
--
ALTER TABLE `req`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `fname` (`fname`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `degrees`
--
ALTER TABLE `degrees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `departmentts`
--
ALTER TABLE `departmentts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `facultys`
--
ALTER TABLE `facultys`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `message_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=175;

--
-- AUTO_INCREMENT for table `professors`
--
ALTER TABLE `professors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `req`
--
ALTER TABLE `req`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `degrees`
--
ALTER TABLE `degrees`
  ADD CONSTRAINT `iddd` FOREIGN KEY (`id`) REFERENCES `students` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
