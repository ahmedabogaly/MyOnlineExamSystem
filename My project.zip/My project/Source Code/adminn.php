<?php
    session_start();
    $sessionId = $_SESSION['id'] ?? '';
    $sessionRole = $_SESSION['role'] ?? '';
    echo "$sessionId $sessionRole";
    if ( !$sessionId && !$sessionRole ) {
        header( "location:login.php" );
        die();
    }

    ob_start();

    include_once "config.php";
    $connection = mysqli_connect( DB_HOST, DB_USER, DB_PASSWORD, DB_NAME );
    if ( !$connection ) {
        echo mysqli_error( $connection );
        throw new Exception( "Database cannot Connect" );
    }

    $id = $_REQUEST['id'] ?? 'dashboard';
    $action = $_REQUEST['action'] ?? '';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=1024">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/bootstrap-glyphicons.css" type="text/css" rel="stylesheet">
    <link href="css/font-awesome.css" type="text/css" rel="stylesheet">
    <link href="css/my_style.css" type="text/css" rel="stylesheet">
    
</head>

<body>
    <!--------------------------------- Secondary Navber -------------------------------->
    <section class="topber">
        <div class="topber__title">
            <span class="topber__title--text">
                <?php
                    if ( 'addfaculty' == $id ) 
                    {
                        echo "Add level";
                    } 
                    elseif ( 'allfaculty' == $id ) 
                    {
                        echo "levels";
                    } 
                    if ( 'adddepartmentt' == $id ) 
                    {
                        echo "Add department";
                    } 
                    elseif ( 'alldepartmentt' == $id ) 
                    {
                        echo "departments";
                    } 
                    elseif ( 'addprofessor' == $id ) 
                    {
                        echo "Add professor";
                    } 
                    elseif ( 'allprofessor' == $id ) 
                    {
                        echo "professors";
                    } 
                    elseif ( 'addstudent' == $id ) 
                    {
                        echo "Add student";
                    } 
                    elseif ( 'allstudent' == $id ) 
                    {
                        echo "students";
                    } 
                    elseif ( 'userProfile' == $id ) 
                    {
                        echo "Your Profile";
                    } 
                    elseif ( 'editfaculty' == $action ) 
                    {
                        echo "Edit level";
                    }
                    elseif ( 'editdepartmentt' == $action ) 
                    {
                        echo "Edit department";
                    } 
                    elseif ( 'editprofessor' == $action ) 
                    {
                        echo "Edit professor";
                    } 
                    elseif ( 'editstudent' == $action ) 
                    {
                        echo "Edit student";
                    }
                    elseif ( 'messages' == $id ) 
                    {
                        echo "messages";
                    }
                    elseif ( 'reqprof' == $id ) 
                    {
                        echo "Professors Requests";
                    }  

                ?>

            </span>
        </div>

        <div class="topber__profile">
            <?php
                $query = "SELECT fname,lname,role,avatar FROM {$sessionRole}s WHERE id='$sessionId'";
                $result = mysqli_query( $connection, $query );

                if ( $data = mysqli_fetch_assoc( $result ) ) {
                    $fname = $data['fname'];
                    
                    $role = $data['role'];  
                    $avatar= $data['avatar'];
                ?>            
                           
                <div class="dropdown">
                    <button class="btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <?php
                        echo "Your Account";
                        }
                    ?>
                    </button>                    
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <?php if ( 'student' == $sessionRole) {?>
                                 <?php printf( "<a href='adminn.php?action=viewstudent&id=%s'><i class='dropdown-item'>Profile</i></a>", $sessionId)?>
                            <?php }?>
                            <?php if ( 'professor' == $sessionRole) {?>
                                 <?php printf( "<a href='adminn.php?action=viewprofessor&id=%s'><i class='dropdown-item'>Profile</i></a>", $sessionId)?>
                            <?php }?>
                            <?php if ( 'admin' == $sessionRole) {?>
                                 <?php printf( "<a href='adminn.php?action=viewadmin&id=%s'><i class='dropdown-item'>Profile</i></a>", $sessionId)?>
                            <?php }?>                            

                            <a class="dropdown-item" href="logout.php"><i>Log Out</i></a>
                        </div>                                                    
                </div>
        </div>
    </section>
    <!--------------------------------- Secondary Navber -------------------------------->


    <!--------------------------------- Sideber -------------------------------->
    <section id="sideber" class="sideber" >
        <ul class="sideber__ber" >
            <h3 class="sideber__panel"><i id="left" class="far fa-lightbulb"></i> Hello Admin</h3>
            
            <?php if ( 'admin' == $sessionRole ) {?>
                <!-- Only For Admin -->
                <li id="left" class="sideber__item sideber__item--modify<?php if ( 'addfaculty' == $id ) {
                                                                            echo " active";
                                                                        }?>">
                    <a href="adminn.php?id=addfaculty"><i id="left" class="fas fa-plus"></i></i>Add level</a>
                </li><?php }?>


            <li id="left" class="sideber__item<?php if ( 'allfaculty' == $id ) {
    echo " active";
}?>">
                <a href="adminn.php?id=allfaculty"><i id="left" class="fas fa-school"></i>All levels</a>
            </li>

            <?php if ( 'admin' == $sessionRole ) {?>
                <!-- Only For Admin -->
                <li id="left" class="sideber__item sideber__item--modify<?php if ( 'adddepartmentt' == $id ) {
                                                                            echo " active";
                                                                        }?>">
                    <a href="adminn.php?id=adddepartmentt"><i id="left" class="fas fa-plus"></i></i>Add department</a>
                </li><?php }?>


            <li id="left" class="sideber__item<?php if ( 'alldepartmentt' == $id ) {
    echo " active";
}?>">
                <a href="adminn.php?id=alldepartmentt"><i id="left" class="fa fa-list-alt"></i>All department</a>
            </li>

            <?php if ( 'admin' == $sessionRole  ) {?>
                <!-- For Admin -->
                <li id="left" class="sideber__item sideber__item--modify<?php if ( 'addprofessor' == $id ) {
                                                                            echo " active";
                                                                        }?>">
                    <a href="adminn.php?id=addprofessor"><i id="left" class="fas fa-plus"></i></i>Add
                        professor</a>
                </li><?php }?>


            <li id="left" class="sideber__item<?php if ( 'allprofessor' == $id ) {
    echo " active";
}?>">
                <a href="adminn.php?id=allprofessor"><i id="left" class="fa fa-chalkboard-teacher"></i>All professor</a>
            </li>


            <?php if ( 'admin' == $sessionRole ) {?>
                <!-- For Admin -->
                <li id="left" class="sideber__item sideber__item--modify<?php if ( 'addstudent' == $id ) {
                                                                            echo " active";
                                                                        }?>">
                    <a href="adminn.php?id=addstudent"><i id="left" class="fas fa-plus"></i>Add student</a>
                </li><?php }?>

            <li id="left" class="sideber__item<?php if ( 'allstudent' == $id ) {
    echo " active";
}?>">
                <a href="adminn.php?id=allstudent"><i id="left" class="fas fa-user-graduate"></i>All student</a>
            </li>        

            <?php if ( 'student' == $sessionRole || 'professor' == $sessionRole) {?>

            <li id="left" class="sideber__item<?php if ( 'messages' == $id ) {
    echo " active";
}?>">
                <a href="adminn.php?id=messages"><i id="left" class="fa fa-envelope"></i>messages</a>
            </li><?php }?>   

            <?php if ( 'admin' == $sessionRole ) {?>
                <!-- Only For Admin -->
                <li id="left" class="sideber__item sideber__item--modify<?php if ( 'reqprof' == $id ) {
                                                                            echo " active";
                                                                        }?>">
                    <a href="adminn.php?id=reqprof"><i id="left" class="fas fa-external-link-alt"></i></i>Professors Requests</a>
                </li><?php }?>         
        </ul>
    </section>
    <!--------------------------------- #Sideber -------------------------------->


    <!--------------------------------- Main section -------------------------------->
    <section class="main">
        <div class="container">
            <!-- ---------------------- DashBoard ------------------------ -->
            <?php if ( 'dashboard' == $id ) {?>
                
            <?php }?>
            <!-- ---------------------- DashBoard ------------------------ -->



            <!-- ---------------------- faculty ------------------------ -->
            <div class="faculty">
                <?php if ( 'allfaculty' == $id ) {?>
                    <div class="allfaculty">
                        <div class="main__table" style="width: 1000">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col">Level Number</th>
                                        <th scope="col">Brief clarification</th>
                                        <th scope="col">Subjects</th>
                                        <th scope="col">Facebook Page</th>
                                        <th scope="col">See</th>

                                        <?php if ( 'admin' == $sessionRole ) {?>
                                            <!-- Only For Admin -->
                                            <th scope="col">Edit</th>
                                            <th scope="col">Delete</th>
                                        <?php }?>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php
                                        $getfacultys = "SELECT * FROM facultys";
                                            $result = mysqli_query( $connection, $getfacultys );

                                        while ( $faculty = mysqli_fetch_assoc( $result ) ) {?>

                                        <tr>
                                            <td><?php printf( "%s", $faculty['phone'] );?></td>
                                            <td><?php printf( "%s", $faculty['declaration'] );?></td>
                                            <td><?php printf( "%s", $faculty['departments'] );?></td>
                                            <td><center><?php printf( "<a href='%s'><i class='fab fa-facebook-f'></i></a>", $faculty['website'] , $faculty['website']);?></center></td>
                                            <td><center><?php printf( "<a href='adminn.php?action=viewfaculty&id=%s'><i class='fa fa-eye'></i></a>", $faculty['id'] )?></center></td>

 
                                            <?php if ( 'admin' == $sessionRole ) {?>
                                                <!-- Only For Admin -->
                                                <td><center><?php printf( "<a href='adminn.php?action=editfaculty&id=%s'><i class='fas fa-edit'></i></a>", $faculty['id'] )?></center></td>
                                                <td><center><?php printf( "<a class='delete' href='adminn.php?action=deletefaculty&id=%s'><i class='fas fa-trash'></i></a>", $faculty['id'] )?></center></td>
                                            <?php }?>
                                        </tr>

                                    <?php }?>

                                </tbody>
                            </table>


                        </div>
                    </div>
                <?php }?>

                <?php if ( 'addfaculty' == $id ) {?>
                    <div class="addfaculty">
                        <div class="main__form">
                            <div class="main__form--title text-center">Add New level</div>
                            <form action="add.php" method="POST">
                            
                                <div class="form-row">
                                    
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-bars"></i>
                                            <input type="number" name="phone" placeholder="Level Number" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-bars"></i>
                                            <input id="pwdinput" type="text" name="declaration" placeholder="Brief clarification" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-bars"></i>
                                            <input id="pwdinput" type="text" name="departments" placeholder="Subjects" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fab fa-facebook-f"></i>
                                            <input type="text" name="website" placeholder="Facebook Page" required>
                                        </label>
                                    </div>
                                    
                                    
                                    
                                    <input type="hidden" name="action" value="addfaculty">
                                    <div class="col col-12">
                                        <input type="submit" value="Submit">
                                    </div>
                                </div>
                            </form>
                        </div>

                    </div>
                <?php }?>

                <?php if ( 'editfaculty' == $action ) {
                        $facultyId = $_REQUEST['id'];
                        $selectfacultys = "SELECT * FROM facultys WHERE id='{$facultyId}'";
                        $result = mysqli_query( $connection, $selectfacultys );

                    $faculty = mysqli_fetch_assoc( $result );?>
                    <div class="addfaculty">
                        <div class="main__form">
                            <div class="main__form--title text-center">Update level</div>
                            <form action="add.php" method="POST">
                                <div class="form-row">
                                   
                                    
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-bars"></i>
                                            <input type="number" name="phone" placeholder="Phone" value="<?php echo str_replace ('<br/>', ',', $faculty['phone']); ?>" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-bars"></i>
                                            <input type="text" name="declaration" placeholder="Brief clarification" value="<?php echo str_replace('<br/>', ',', $faculty['declaration']); ?>" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-bars"></i>
                                            <input type="text" name="departments" placeholder="Subjects" value="<?php echo str_replace('<br/>', ',', $faculty['departments']); ?>" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fab fa-facebook-f"></i>
                                            <input type="text" name="website" placeholder="website" value="<?php echo $faculty['website']; ?>" required>
                                        </label>
                                    </div>
                                    
                                    
                                    
                                    <input type="hidden" name="action" value="updatefaculty">
                                    <input type="hidden" name="id" value="<?php echo $facultyId; ?>">
                                    <div class="col col-12">
                                        <input type="submit" value="Update">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php }?>

                <?php if ( 'deletefaculty' == $action ) {
                        $facultyId = $_REQUEST['id'];
                        $deletefaculty = "DELETE FROM facultys WHERE id ='{$facultyId}'";
                        $result = mysqli_query( $connection, $deletefaculty );
                        header( "location:adminn.php?id=allfaculty" );
                }?>
            </div>
            <!-- ---------------------- faculty ------------------------ -->



            <!-- ---------------------- departmentt --------------------- -->

            <div class="faculty">
                <?php if ( 'alldepartmentt' == $id ) {?>
                    <div class="alldepartmentt">
                        <div class="main__table" style="width: 1000">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col">Name</th></center>
                                        <th scope="col">Abbreviation</th></center>
                                        <th scope="col">Brief clarification</th>
                                        <th scope="col">Subjects</th>
                                        <th scope="col">See</th>

                                        <?php if ( 'admin' == $sessionRole ) {?>
                                            <!-- Only For Admin -->
                                            <th scope="col">Edit</th>
                                            <th scope="col">Delete</th>
                                        <?php }?>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php
                                           $getdepartmentts = "SELECT * FROM departmentts";
                                            $result = mysqli_query( $connection, $getdepartmentts );

                                        while ( $departmentt = mysqli_fetch_assoc( $result ) ) {?>

                                        <tr>
                                            <td><?php printf( "%s", $departmentt['name'] );?></td>
                                            <td><?php printf( "%s", $departmentt['Abbreviation'] );?></td>
                                            <td><?php printf( "%s", $departmentt['Clarification'] );?></td>
                                            <td><?php printf( "%s", $departmentt['availablefacultys'] );?></td>
                                            <td><center><?php printf( "<a href='adminn.php?action=viewdepartmentt&id=%s'><i class='fa fa-eye'></i></a>", $departmentt['id'] )?></center></td>


                                            <?php if ( 'admin' == $sessionRole ) {?>
                                                <!-- Only For Admin -->
                                                <td><center><?php printf( "<a href='adminn.php?action=editdepartmentt&id=%s'><i class='fas fa-edit'></i></a>", $departmentt['id'] )?></center></td>
                                                <td><center><?php printf( "<a class='delete' href='adminn.php?action=deletedepartmentt&id=%s'><i class='fas fa-trash'></i></a>", $departmentt['id'] )?></center></td>
                                            <?php }?>
                                        </tr>

                                    <?php }?>

                                </tbody>
                            </table>


                        </div>
                    </div>
                <?php }?>

                <?php if ( 'adddepartmentt' == $id ) {?>
                    <div class="adddepartmentt">
                        <div class="main__form">
                            <div class="main__form--title text-center">Add New department</div>
                            <form action="add.php" method="POST">
                                
                                <div class="form-row">
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-user-circle"></i>
                                            <input type="text" name="name" placeholder="Department Name" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-laptop-code"></i>
                                            <input type="text" name="Abbreviation" placeholder="Department Abbreviation" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-info"></i>
                                            <input type="text" name="Clarification" placeholder="Brief clarification for depatrment" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-bars"></i>
                                            <input type="text" name="availablefacultys" placeholder="Subjects" required>
                                        </label>
                                    </div>
                                    
                                    
                                    <input type="hidden" name="action" value="adddepartmentt">
                                    <div class="col col-12">
                                        <input type="submit" value="Submit">
                                    </div>
                                </div>
                            </form>
                        </div>

                    </div>
                <?php }?>

                <?php if ( 'editdepartmentt' == $action ) {
                        $departmenttId = $_REQUEST['id'];
                        $selectdepartmentts = "SELECT * FROM departmentts WHERE id='{$departmenttId}'";
                        $result = mysqli_query( $connection, $selectdepartmentts );

                    $departmentt = mysqli_fetch_assoc( $result );?>
                    <div class="adddepartmentt">
                        <div class="main__form">
                            <div class="main__form--title text-center">Update department</div>
                            <form action="add.php" method="POST">
                                <div class="form-row">
                                   
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-user-circle"></i>
                                            <input type="text" name="name" placeholder="Department Name" value="<?php echo $departmentt['name']; ?>" required>
                                        </label>
                                    </div>

                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-laptop-code"></i>
                                            <input type="text" name="Abbreviation" placeholder="Department Abbreviation" value="<?php echo $departmentt['Abbreviation']; ?>" required>
                                        </label>
                                    </div>
                                    
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-info"></i>
                                            <input type="text" name="Clarification" placeholder="Brief clarification for depatrment" value="<?php echo $departmentt['Clarification']; ?>" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-bars"></i>
                                            <input type="text" name="availablefacultys" placeholder="Subjects" value="<?php echo str_replace('<br/>', ',', $departmentt['availablefacultys']); ?>" required>

                                        </label>
                                    </div>
                                    <input type="hidden" name="action" value="updatedepartmentt">
                                    <input type="hidden" name="id" value="<?php echo $departmenttId; ?>">
                                    <div class="col col-12">
                                        <input type="submit" value="Update">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php }?>

                <?php if ( 'viewdepartmentt' == $action ) {
                        $departmenttID = $_REQUEST['id'];
                        $selectdepartmentt = "SELECT * FROM departmentts WHERE id='{$departmenttID}'";
                        $result = mysqli_query( $connection, $selectdepartmentt );

                    $departmentt = mysqli_fetch_assoc( $result );?>
                    <div class="adddepartmentt">
                        <div class="main__form">
                            <div class="main__form--title text-center"></div>
                            <form action="add.php" method="POST">
                                <div class="form-row">
                                    <div class="form-row">
                                     <div class="col col-12" style="text-align: center;">   
                                        <h2>Department</h2>
                                     </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-user-circle"></i>
                                            <input type="text" name="name" readonly="" value="<?php echo $departmentt['name']; ?>" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-laptop-code"></i>
                                            <input type="text" name="Abbreviation" readonly="" value="<?php echo $departmentt['Abbreviation']; ?>" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-info"></i></i>
                                            <input type="text" name="Clarification" readonly="" value="<?php echo $departmentt['Clarification']; ?>" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-bars"></i></i>
                                            <input type="text" name="availablefacultys" readonly="" value="<?php echo str_replace('<br/>', ',', $departmentt['availablefacultys']); ?>" required>

                                        </label>
                                    </div>
                                    
                                    
                                    <input type="hidden" name="action" value="adddepartmentt">
                                    
                                </div>
                                                                                                                                    
                                    
                                </div>
                            </form>
                        </div>
                    </div>
                <?php }?>

                <?php if ( 'deletedepartmentt' == $action ) {
                        $departmenttId = $_REQUEST['id'];
                        $deletedepartmentt = "DELETE FROM departmentts WHERE id ='{$departmenttId}'";
                        $result = mysqli_query( $connection, $deletedepartmentt );
                        header( "location:adminn.php?id=alldepartmentt" );
                }?>
            </div>


            <!-- ---------------------- # departmentt# -------------------- -->




            <!-- ----------------------     professor ------------------------ -->
            <div class="professor">
                <?php if ( 'allprofessor' == $id ) {?>
                    <div class="allprofessor">
                        <div class="main__table" style="width: 1000">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col">Name</th>
                                        <th scope="col">Email</th>                                        
                                        <th scope="col">Phone</th>
                                        <th scope="col">Address</th>
                                        <th scope="col">Department</th>   
                                        <th scope="col">Subject</th>
                                        <th scope="col">See</th>
                                        <?php if ( 'student' == $sessionRole || 'professor' == $sessionRole ) {?>
                                            <th scope="col">Contact</th>
                                        <?php }?>
                                        
                                        <?php if ( 'admin' == $sessionRole  ) {?>
                                            <!-- For Admin-->
                                            <th scope="col">Edit</th>
                                            <th scope="col">Delete</th>
                                        <?php }?>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php
                                        $getprofessor = "SELECT * FROM professors";
                                            $result = mysqli_query( $connection, $getprofessor );

                                        while ( $professor = mysqli_fetch_assoc( $result ) ) {?>

                                        <tr>
                                            
                                            <td><?php printf( "%s %s", $professor['fname'], $professor['lname'] );?></td>
                                            <td><?php printf( "%s", $professor['email'] );?></td>
                                            <td><?php printf( "%s", $professor['phone'] );?></td>
                                            <td><?php printf( "%s", $professor['Address'] );?></td>
                                            <td><?php printf( "%s", $professor['DepartmentName'] );?></td>
                                            <td><?php printf( "%s", $professor['Subjects'] );?></td>
                                            <td><center><?php printf( "<a href='adminn.php?action=viewprofessor&id=%s'><i class='fas fa-eye'></i></a>", $professor['id'] )?></center></td>


                                            <?php if ( 'student' == $sessionRole)
                                            {?>
                                                <td><center><?php printf( "<a href='adminn.php?action=contactprof&id=%s'><i class='fas fa-envelope'></i></a>", $professor['id'] )?></center></td>
                                            <?php }?>
                                            <?php if ( 'professor' == $sessionRole && $professor['id'] !== $sessionId)
                                            {?>
                                                <td><center><?php printf( "<a href='adminn.php?action=contactprof&id=%s'><i class='fas fa-envelope'></i></a>", $professor['id'] )?></center></td>
                                            <?php }?>


                                                                                    
                                            <?php if ( 'admin' == $sessionRole || 'faculty' == $sessionRole ) {?>
                                                <!-- For Admin, faculty -->
                                                <td><center><?php printf( "<a href='adminn.php?action=editprofessor&id=%s'><i class='fas fa-edit'></i></a>", $professor['id'] )?></center></td>
                                                <td><center><?php printf( "<a class='delete' href='adminn.php?action=deleteprofessor&id=%s'><i class='fas fa-trash'></i></a>", $professor['id'] )?></center></td>
                                            <?php }?>
                                        </tr>

                                    <?php }?>

                                </tbody>
                            </table>


                        </div>
                    </div>
                <?php }?>

                <?php if ( 'addprofessor' == $id ) {?>
                    <div class="addprofessor">
                        <div class="main__form">
                            <div class="main__form--title text-center">Add New professor</div>
                            <form action="add.php" method="POST">
                                <div class="form-row">    
                                                                                                    
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-user-circle"></i>
                                            <input type="text" name="fname" placeholder="Name" required>
                                        </label>
                                    </div>                                    
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-envelope"></i>
                                            <input type="email" name="email" placeholder="Email" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-phone-alt"></i>
                                            <input type="number" name="phone" placeholder="Phone" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-key"></i>
                                            <input id="pwdinput" type="password" name="password" placeholder="Password" required>
                                            <i id="pwd" class="fas fa-eye right"></i>

                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="far fa-address-card"></i>
                                            <input type="text" name="Address" placeholder="Address" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fa fa-list-alt"></i>
                                            <input type="text" name="DepartmentName" placeholder="Department" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-book-open"></i>
                                            <input type="text" name="Subjects" placeholder="Subjects" required>
                                        </label>
                                    </div>
                                    
                                    <input type="hidden" name="action" value="addprofessor">
                                    <div class="col col-12">
                                        <input type="submit" value="Submit">
                                    </div>
                                </div>
                            </form>
                        </div>

                    </div>
                <?php }?>

                <?php if ( 'editprofessor' == $action ) {
                        $professorID = $_REQUEST['id'];
                        $selectprofessor = "SELECT * FROM professors WHERE id='{$professorID}'";
                        $result = mysqli_query( $connection, $selectprofessor );

                    $professor = mysqli_fetch_assoc( $result );?>
                    <div class="addfaculty">
                        <div class="main__form">
                            <div class="main__form--title text-center">Update professor</div>
                            <form action="add.php" method="POST">
                                <div class="form-row">
                                    
                                    
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-user-circle"></i>
                                            <input type="text" name="fname" placeholder="Name" value="<?php echo $professor['fname']; ?>" required>
                                        </label>
                                    </div>                                    
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-envelope"></i>
                                            <input type="email" name="email" placeholder="Email" value="<?php echo $professor['email']; ?>" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-key"></i>
                                            <input id="pwdinput" type="password" name="oldPassword" placeholder="Old Password" required>
                                            <i id="pwd" class="fas fa-eye right"></i>
                                        </label>
                                     </div>
                                     <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-key"></i>
                                            <input id="pwdinput" type="password" name="newPassword" placeholder="New Password" required>
                                            <p>Type Old Password if you don't want to change</p>
                                            <i id="pwd" class="fas fa-eye right"></i>
                                        </label>
                                     </div>                                 
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-phone-alt"></i>
                                            <input type="number" name="phone" placeholder="Phone" value="<?php echo str_replace('<br/>', ',', $professor['phone']); ?>" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="far fa-address-card"></i>
                                            <input type="text" name="Address" placeholder="Address" value="<?php echo $professor['Address']; ?>" required>
                                        </label>
                                    </div>
                                    
                                    
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fa fa-list-alt"></i>
                                            <input type="text" name="DepartmentName" placeholder="Department" value="<?php echo str_replace('<br/>', ',', $professor['DepartmentName']); ?>" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-book-open"></i>
                                            <input type="text" name="Subjects" placeholder="Subjects" value="<?php echo str_replace('<br/>', ',', $professor['Subjects']); ?>" required>
                                        </label>
                                    </div>
                                                                      
                                    <input type="hidden" name="action" value="updateprofessor">
                                    <input type="hidden" name="id" value="<?php echo $professorID; ?>">
                                    <div class="col col-12">
                                        <input type="submit" value="Update">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php }?>

                <?php if ( 'viewprofessor' == $action ) {
                        $professorID = $_REQUEST['id'];
                        $selectprofessor = "SELECT * FROM professors WHERE id='{$professorID}'";
                        $result = mysqli_query( $connection, $selectprofessor );

                    $professor = mysqli_fetch_assoc( $result );?>
                    <div class="addfaculty">
                        <div class="main__form">
                            <form action="add.php" method="POST">
                                <div class="form-row">
                                    
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-user-circle"></i>
                                            <input type="text" name="fname" readonly="" value="<?php echo $professor['fname']; ?>" required>
                                        </label>
                                    </div>
                                    
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-envelope"></i>
                                            <input type="email" name="email" readonly="" value="<?php echo $professor['email']; ?>" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-phone-alt"></i>
                                            <input type="number" name="phone" readonly="" value="<?php echo str_replace('<br/>', ',', $professor['phone']); ?>" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="far fa-address-card"></i>
                                            <input type="text" name="Address" readonly="" value="<?php echo $professor['Address']; ?>" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fa fa-list-alt"></i>
                                            <input type="text" name="DepartmentName" readonly="" value="<?php echo str_replace('<br/>', ',', $professor['DepartmentName']); ?> Department" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-book-open"></i>
                                            <input type="text" name="Subjects" readonly="" value="<?php echo str_replace('<br/>', ',', $professor['Subjects']); ?>" required>
                                        </label>
                                    </div>                                                        
                            </form>
                        </div>
                    </div>
                <?php }?>



                <?php if ( 'deleteprofessor' == $action ) {
                        $professorID = $_REQUEST['id'];
                        $deleteprofessor = "DELETE FROM professors WHERE id ='{$professorID}'";
                        $result = mysqli_query( $connection, $deleteprofessor );
                        header( "location:adminn.php?id=allprofessor" );
                }?>
            </div>
            <!-- ---------------------- professor ------------------------ -->

            <!-- ---------------------- student ------------------------ -->
            <div class="student">
                <?php if ( 'allstudent' == $id ) {?>
                    <div class="allstudent">
                        <div class="main__table" style="width: 1000"  >
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col">Name</th>
                                        <th scope="col">Email</th>
                                        <th scope="col">Phone</th>                                        
                                        <th scope="col">Department</th>    
                                        <th scope="col">Level</th>
                                        <?php if ( 'admin' == $sessionRole || 'professor' == $sessionRole ) {?>
                                            <!-- For Admin, faculty, professor-->
                                            <th scope="col">CGPA</th>
                                        <?php }?>
                                        <th scope="col">See</th>     
                                       
                                        <?php if ( 'student' == $sessionRole || 'professor' == $sessionRole ) {?>
                                            <!-- For Admin, faculty, professor-->
                                            <th scope="col">Contact</th>
                                        <?php }?>

                                        <?php if ( 'professor' == $sessionRole ) {?>
                                            <!-- For Admin, faculty, professor-->
                                            <th scope="col">Report</th>
                                        <?php }?>
                                        
                                        <?php if ( 'admin' == $sessionRole ) {?>
                                            <!-- For Admin-->
                                            <th scope="col">Edit</th>
                                            <th scope="col">Delete</th>
                                        <?php }?>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php
                                        $getstudent = "SELECT * FROM students";
                                            $result = mysqli_query( $connection, $getstudent );

                                        while ( $student = mysqli_fetch_assoc( $result ) ) {?>

                                        <tr>
                                            
                                             
                                            <td><?php printf( "%s", $student['fname'] );?></td>
                                            <td><?php printf( "%s", $student['email'] );?></td>
                                            <td><?php printf( "%s", $student['phone'] );?></td> 
                                            
                                            <td><?php printf( "%s", $student['DepartmentName'] );?></td>
                                            <td><?php printf( "%s", $student['levelnumber'] );?></td>
                                            <?php if ( 'admin' == $sessionRole || 'professor' == $sessionRole ) {?>
                                                <td><?php printf( "%s", $student['CGPA'] );?></td>
                                            <?php }?>
                                            <td><center><?php printf( "<a href='adminn.php?action=viewstudent&id=%s'><i class='fa fa-eye'></i></a>", $student['id'] )?></center></td>
                                            
                                            <?php if ( 'student' == $sessionRole && $student['id'] !== $sessionId)
                                            {?>
                                                <td><center><?php printf( "<a href='adminn.php?action=contact&id=%s'><i class='fas fa-envelope'></i></a>", $student['id'] )?></center></td>
                                            <?php }?>
                                            <?php if ( 'professor' == $sessionRole)
                                            {?>
                                                <td><center><?php printf( "<a href='adminn.php?action=contact&id=%s'><i class='fas fa-envelope'></i></a>", $student['id'] )?></center></td>
                                            <?php }?>
                                            

                                            <?php if ( 'professor' == $sessionRole ) {?>
                                                <!-- For professor , student--> 
                                                <td><center><?php printf( "<a href='adminn.php?action=report&id=%s'><i class='fas fa-print'></i></a>", $student['id'] )?></center></td>
                                                </td>                                                
                                            <?php }?>
                                                
                                            <?php if ( 'admin' == $sessionRole ) {?>
                                                <!-- For Admin-->
                                                <td><center><?php printf( "<a href='adminn.php?action=editstudent&id=%s'><i class='fas fa-edit'></i></a>", $student['id'] )?></center></td>
                                                <td><center><?php printf( "<a class='delete' href='adminn.php?action=deletestudent&id=%s'><i class='fas fa-trash'></i></a>", $student['id'] )?> </center></td>
                                            <?php }?>
                                        </tr>

                                    <?php }?>

                                </tbody>
                            </table>


                        </div>
                    </div>
                <?php }?>

                <?php if ( 'addstudent' == $id ) {?>
                    <div class="addstudent">
                        <div class="main__form">
                            <div class="main__form--title text-center">Add New student</div>
                            <form action="add.php" method="POST">
                                <div class="form-row">
                                    
                                    
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-user-circle"></i>
                                            <input type="text" name="fname" placeholder="Name" required>
                                        </label>
                                    </div>                                    
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-envelope"></i>
                                            <input type="email" name="email" placeholder="Email" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-phone-alt"></i>
                                            <input type="number" name="phone" placeholder="Phone" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-key"></i>
                                            <input id="pwdinput" type="password" name="password" placeholder="Password" required>
                                            <i id="pwd" class="fas fa-eye right"></i>
                                        </label>                                        
                                    </div>
                                    
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fa fa-list-alt"></i>
                                            <input type="text" name="DepartmentName" placeholder="Department" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fa fa-signal"></i>
                                            <input type="text" name="levelnumber" placeholder="level" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fa fa-circle"></i>
                                            <input type="text" name="CGPA" placeholder="CGPA" required>
                                        </label>
                                    </div>
                                    <input type="hidden" name="action" value="addstudent">
                                    <div class="col col-12">
                                        <input type="submit" value="Submit">
                                    </div>
                                </div>
                            </form>
                        </div>

                    </div>
                <?php }?>

                <?php if ( 'editstudent' == $action ) {
                        $studentID = $_REQUEST['id'];
                        $selectstudent = "SELECT * FROM students WHERE id='{$studentID}'";
                        $result = mysqli_query( $connection, $selectstudent );

                    $student = mysqli_fetch_assoc( $result );?>
                    <div class="addfaculty">
                        <div class="main__form">
                            <div class="main__form--title text-center">Update student</div>
                            <form action="add.php" method="POST">
                                <div class="form-row">
                                    

                                   
                                    
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-user-circle"></i>
                                            <input type="text" name="fname" placeholder="Name" value="<?php echo $student['fname']; ?>" required>
                                        </label>
                                    </div>                                    
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-envelope"></i>
                                            <input type="email" name="email" placeholder="Email" value="<?php echo $student['email']; ?>" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-key"></i>
                                            <input id="pwdinput" type="password" name="oldPassword" placeholder="Old Password" required>
                                            <i id="pwd" class="fas fa-eye right"></i>
                                        </label>
                                     </div>
                                     <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-key"></i>
                                            <input id="pwdinput" type="password" name="newPassword" placeholder="New Password" required>
                                            <p>Type Old Password if you don't want to change</p>
                                            <i id="pwd" class="fas fa-eye right"></i>
                                        </label>
                                     </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-phone-alt"></i>
                                            <input type="number" name="phone" placeholder="Phone" value="<?php echo str_replace('<br/>', ',', $student['phone']); ?>" required>
                                        </label>
                                    </div>
                                    

                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fa fa-list-alt"></i>
                                            <input type="text" name="DepartmentName" placeholder="Department" value="<?php echo $student['DepartmentName']; ?>" required>
                                        </label>
                                    </div>

                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fa fa-signal"></i>
                                            <input type="text" name="levelnumber" placeholder="Level" value="<?php echo $student['levelnumber']; ?>" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fa fa-circle"></i>
                                            <input type="text" name="CGPA" placeholder="CGPA" value="<?php echo $student['CGPA']; ?>" required>
                                        </label>
                                    </div>
                                    <input type="hidden" name="action" value="updatestudent">
                                    <input type="hidden" name="id" value="<?php echo $studentID; ?>">
                                    <div class="col col-12">
                                        <input type="submit" value="Update">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php }?>

                <?php if ( 'editadmin' == $action ) {
                        $adminID = $_REQUEST['id'];
                        $selectadmin = "SELECT * FROM admins WHERE id='{$adminID}'";
                        $result = mysqli_query( $connection, $selectadmin );

                    $admin = mysqli_fetch_assoc( $result );?>
                    <div class="addfaculty">
                        <div class="main__form">
                            <div class="main__form--title text-center">Update admin</div>
                            <form action="add.php" method="POST">
                                <div class="form-row">
                                    
                                    
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-user-circle"></i>
                                            <input type="text" name="fname" placeholder="Name" value="<?php echo $admin['fname']; ?>" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-phone-alt"></i>
                                            <input type="number" name="phone" placeholder="Phone" value="<?php echo str_replace('<br/>', ',', $admin['phone']); ?>" required>
                                        </label>
                                    </div>                                    
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-envelope"></i>
                                            <input type="email" name="email" placeholder="Email" value="<?php echo $admin['email']; ?>" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-key"></i>
                                            <input id="pwdinput" type="password" name="oldPassword" placeholder="Old Password" required>
                                            <i id="pwd" class="fas fa-eye right"></i>
                                        </label>
                                     </div>
                                     <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-key"></i>
                                            <input id="pwdinput" type="password" name="newPassword" placeholder="New Password" required>
                                            <p>Type Old Password if you don't want to change</p>
                                            <i id="pwd" class="fas fa-eye right"></i>
                                        </label>
                                     </div>
                                    
                                    
                                    <input type="hidden" name="action" value="updateadmin">
                                    <input type="hidden" name="id" value="<?php echo $adminID; ?>">
                                    <div class="col col-12">
                                        <input type="submit" value="Update">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php }?>



                <!---------------------------------------------------------------------------->

                    <!-----------------------test-------------------------------->
                <?php if ( 'contact' == $action ) {?>

                <?php $conn = new PDO('mysql:host=localhost;dbname=mydatabase', 'root', ''); ?>

                <?php if ( 'student' == $sessionRole ) {?>
                    
                    <?php $session_query = $conn->query("select * from students where id = '$sessionId'"); ?>
                    
                <?php }?>

                <?php if ( 'professor' == $sessionRole ) {?>
                                                 
                    <?php $session_query = $conn->query("select * from professors where id = '$sessionId'"); ?>

                <?php }?>

                <?php                                           

                $user_row = $session_query->fetch();
                $username = $user_row['fname']." ".$user_row['lname'];
                $avatar = $user_row['avatar'];
                ?>
                        
                <div class="col-md-6 col-sm-3 text-center">
                    <form method="post" id="send_message" action="send_message.php">                               
                        <div class="control-group">                                                         

                          <div class="controls">
                            
                            <?php

                             $studentID = $_REQUEST['id'];
                             $selectstudent = "SELECT * FROM students WHERE id='{$studentID}'";
                             $result = mysqli_query( $connection, $selectstudent );  

                             ?>

                             <?php if ( 'student' == $sessionRole ) {
                    
                                 $choosestudent = "select * from students where id = '$sessionId'";
                                 $theresult = mysqli_query( $connection, $choosestudent );

                                 if ( $choosestudent = mysqli_fetch_assoc( $theresult ) ) 
                                 {
                                    $receivername = $choosestudent['fname'];
                                 }
                        
                            }?>

                            <?php if ( 'professor' == $sessionRole ) {
                                                 
                            
                                 $chooseproff = "select * from professors where id = '$sessionId'";
                                 $theresult = mysqli_query( $connection, $chooseproff ); 
  
                                 if ( $chooseproff = mysqli_fetch_assoc( $theresult ) ) 
                                 {
                                     $receivername = $chooseproff['fname'];
                                 }   

                            }?>

                             
                             
                            <input type="hidden" name="friend_id" value="<?php echo $studentID; ?>">
                            <?php if ( 'professor' == $sessionRole ) {?>
                                <input type="hidden" name="nameuser" value="prof/ <?php echo $receivername; ?>"> 
                            <?php }?> 
                            <?php if ( 'student' == $sessionRole ) {?>
                                <input type="hidden" name="nameuser" value="student/ <?php echo $receivername; ?>">
                            <?php }?> 
                          </div>
                        </div>
                            

                <div class="control-group">                   
                  <div class="controls">
                    <textarea style="background-color: #F8F8FF;width: 600px;padding: 20px;margin: 10px;color:#008CBA ;font-size: 20px;height: 300" name="my_message" class="my_message" placeholder="Enter Your Message" required></textarea>
                  </div>
                </div>
                <hr>

                <div class="control-group">
                  <div class="controls">
                        <button  class="btn btn-success"style="background-color: #008CBA;"><i class="fa fa-paper-plane"></i> Send </button>
                  </div>
                </div>
                  </form>

                </div>

            <?php }?>



                <?php if ( 'contactprof' == $action ) {?>

                <?php $conn = new PDO('mysql:host=localhost;dbname=mydatabase', 'root', ''); ?>
                                                           
                <?php if ( 'student' == $sessionRole ) {?>
                    
                    <?php $session_query = $conn->query("select * from students where id = '$sessionId'"); ?>
                    
                <?php }?>

                <?php if ( 'professor' == $sessionRole ) {?>
                                                 
                    <?php $session_query = $conn->query("select * from professors where id = '$sessionId'"); ?>

                <?php }?>


                <?php
                $user_row = $session_query->fetch();
                $username = $user_row['fname']." ".$user_row['lname'];
                $avatar = $user_row['avatar'];
                ?>
                        
                <div class="col-md-6 col-sm-3 text-center">
                    <form method="post" id="send_messageprof" action="send_messageprof.php">                               
                        <div class="control-group">                                                         

                          <div class="controls">

                                                        
                            <?php

                             $professorID = $_REQUEST['id'];
                             $selectprofessor = "SELECT * FROM professors WHERE id='{$professorID}'";
                             $result = mysqli_query( $connection, $selectprofessor ); ?>

                             <?php if ( 'student' == $sessionRole ) 
                             {
                    
                                 $choosestudent = "SELECT * FROM students where id = '$sessionId'";
                                 $theresult = mysqli_query( $connection, $choosestudent );

                                 if ( $choosestudent = mysqli_fetch_assoc( $theresult ) ) 
                                 {
                                    $receivername = $choosestudent['fname'];
                                 }
                            }?>

                            <?php if ( 'professor' == $sessionRole ) {
                                                 
                            
                                 $chooseproff = "SELECT * FROM professors where id = '$sessionId'";
                                 $theresult = mysqli_query( $connection, $chooseproff ); 
  
                                 if ( $chooseproff = mysqli_fetch_assoc( $theresult ) ) 
                                 {
                                     $receivername = $chooseproff['fname'];
                                 }   

                            }?>                            

                             
                            <input type="hidden" name="friend_id" value="<?php echo $professorID; ?>">

                            <?php if ( 'professor' == $sessionRole ) {?>
                                <input type="hidden" name="nameuser" value="prof/ <?php echo $receivername; ?>"> 
                            <?php }?> 
                            <?php if ( 'student' == $sessionRole ) {?>
                                <input type="hidden" name="nameuser" value="student/ <?php echo $receivername; ?>">
                            <?php }?>                           

                          </div>
                        </div>
                            

                <div class="control-group">                   
                  <div class="controls">
                    <textarea style="background-color: #F8F8FF;width: 600px;padding: 20px;margin: 10px;color:#008CBA ;font-size: 20px;height: 300" name="my_message" class="my_message" placeholder="Enter Your Message" required></textarea>
                  </div>
                </div>
                <hr>

                <div class="control-group">
                  <div class="controls">
                        <button  class="btn btn-success"style="background-color: #008CBA;"><i class="fa fa-paper-plane"></i> Send </button>
                  </div>
                </div>
                  </form>

                </div>
                  

            <?php }?>
                    <!-----------------------test-------------------------------->
                
                <?php if ( 'viewstudent' == $action ) {
                        $studentID = $_REQUEST['id'];
                        $selectstudent = "SELECT * FROM students WHERE id='{$studentID}'";
                        $result = mysqli_query( $connection, $selectstudent );

                    $student = mysqli_fetch_assoc( $result );?>
                    <div class="addfaculty">
                        <div class="main__form">
                            <div class="main__form--title text-center"></div>
                            <form action="add.php" method="POST">
                                <div class="form-row">
                                    
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-user-circle"></i>
                                            <input type="text" name="fname" readonly="" value="<?php echo $student['fname']; ?>" required>
                                        </label>
                                    </div>
                                    
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-envelope"></i>
                                            <input type="email" name="email" readonly="" value="<?php echo $student['email']; ?>" required>
                                        </label>
                                    </div>

                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-phone-alt"></i>
                                            <input type="number" name="phone" readonly="" value="<?php echo str_replace('<br/>', ',', $student['phone']); ?>" required>
                                        </label>
                                    </div>

                                    

                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fa fa-list-alt"></i>
                                            <input type="text" name="DepartmentName" readonly="" value="<?php echo $student['DepartmentName']; ?> Department" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fa fa-signal"></i>
                                            <input type="text" name="levelnumber" readonly="" value="Level <?php echo $student['levelnumber']; ?>" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fa fa-circle"></i>
                                            <input type="text" name="CGPA" readonly="" value="<?php echo $student['CGPA']; ?> CGPA" required>
                                        </label>
                                    </div>
                                    

                                                                                                

                                    <?php if ('student' == $sessionRole && $studentID == $sessionId) {?>
                                        <div class="col col-12 text-center pb-3">
                                            <input type="button" class="btn btn-success" style="background-color: #008CBA;" onclick="window.location.href='adminn.php?action=editstudent&id=<?php echo $sessionId; ?>';" value="Update" />
                                        </div>
                                     <?php }?>

                                </div>
                            </form>
                        </div>
                    </div>
                <?php }?>

                <?php if ( 'viewadmin' == $action ) {
                        $adminID = $_REQUEST['id'];
                        $selectadmin = "SELECT * FROM admins WHERE id='{$adminID}'";
                        $result = mysqli_query( $connection, $selectadmin );

                    $admin = mysqli_fetch_assoc( $result );?>
                    <div class="addfaculty">
                        <div class="main__form">
                            <div class="main__form--title text-center"></div>
                            <form action="add.php" method="POST">
                                <div class="form-row">
                                    
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-user-circle"></i>
                                            <input type="text" name="fname" readonly="" value="<?php echo $admin['fname']; ?>" required>
                                        </label>
                                    </div>
                                    
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-envelope"></i>
                                            <input type="email" name="email" readonly="" value="<?php echo $admin['email']; ?>" required>
                                        </label>
                                    </div>

                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-phone-alt"></i>
                                            <input type="number" name="phone" readonly="" value="<?php echo str_replace('<br/>', ',', $admin['phone']); ?>" required>
                                        </label>
                                    </div>                                                                           
                                    <div class="col col-12 text-center pb-3">                                                                                     
                                        <?php if ('admin' == $sessionRole && $adminID == $sessionId) {?>
                                            
                                            <input type="button" class="btn btn-success" style="background-color: #008CBA;text-align: center" onclick="window.location.href='adminn.php?action=editadmin&id=<?php echo $sessionId; ?>';" value="Update" />
                                        
                                         <?php }?>
                                     </div>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php }?>

                <?php if ( 'viewfaculty' == $action ) {
                        $facultyID = $_REQUEST['id'];
                        $selectfaculty = "SELECT * FROM facultys WHERE id='{$facultyID}'";
                        $result = mysqli_query( $connection, $selectfaculty );

                    $faculty = mysqli_fetch_assoc( $result );?>
                    <div class="addfaculty">
                        <div class="main__form">
                            <div class="main__form--title text-center"></div>
                            <form action="add.php" method="POST">
                                <div class="form-row">
                                    
                                    
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-bars"></i>
                                            <input type="number" name="phone" readonly="" value="<?php echo str_replace('<br/>', ',', $faculty['phone']); ?>" required>
                                        </label>
                                    </div>
                                    
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-bars"></i>
                                            <input id="pwdinput" type="text" name="declaration" readonly="" value="<?php echo str_replace('<br/>', ',', $faculty['declaration']); ?>" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-bars"></i>
                                            <input id="pwdinput" type="text" name="departments" readonly="" value="<?php echo str_replace('<br/>', ',', $faculty['departments']); ?>" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fab fa-facebook-f"></i>
                                            <input type="text" name="website" readonly="" value="<?php echo $faculty['website']; ?>" required>
                                        </label>
                                    </div>
                                    
                                    <input type="hidden" name="action" value="addfaculty">
                                    
                                </div>
                                                                                                                                    
                                    
                                </div>
                            </form>
                        </div>
                    </div>
                <?php }?>

                <?php if ( 'deletestudent' == $action ) {
                        $studentID = $_REQUEST['id'];
                        $deletestudent = "DELETE FROM students WHERE id ='{$studentID}'";
                        $result = mysqli_query( $connection, $deletestudent );
                        header( "location:adminn.php?id=allstudent" );
                        ob_end_flush();
                }?>
            </div>
            <!-- ---------------------- student ------------------------ -->

            <!-- ------------------------messages----------------------------->
            
            <?php if ( 'student' == $sessionRole || 'professor' == $sessionRole) {?>

            <?php if ( 'messages' == $id ) {?>
                <?php $conn = new PDO('mysql:host=localhost;dbname=mydatabase', 'root', ''); ?>                                               
                <h2 style="color:#666633">&nbsp&nbsp&nbsp Your recived messages</h2>

                <div style=" width: 700px;border: 3px ;padding: 30px;margin: 3px;"
                >                    
                    <hr>

                    <?php if ( 'student' == $sessionRole ) {?>
                    
                    <?php 
                    $query = $conn->query("
                    select 
                        * 
                    from 
                        message
                    LEFT JOIN 
                        students 
                    on 
                        message.stsender_id = students.id                     
                    LEFT JOIN 
                        professors 
                    on 
                        message.profsender_id = professors.id   
                    where 
                        message.streciever_id = '$sessionId'                  
                        ");
                    ?>
                    
                    <?php }?>

                    <?php if ( 'professor' == $sessionRole ) {?>
                                                 
                    <?php 
                    $query = $conn->query("
                    select
                         * 
                    from 
                        message
                    LEFT JOIN 
                        students 
                    on 
                        message.stsender_id = students.id                     
                    LEFT JOIN 
                        professors 
                    on 
                        message.profsender_id = professors.id
                    where 
                        message.profreciever_id = '$sessionId' ");
                     ?>

                    <?php }?>


                    <?php 

                                

                    while($row = $query->fetch()){
                    $id = $row['message_id'];                    
                    
                    ?>
                    
                    <div class="mes">
                        <div style="background-color: #F8F8FF;width: 600px;padding: 20px;margin: 10px;">
                            <textarea style="padding: 2px;margin: 7px;color:#cc0066;font-size: 20px;"readonly><?php echo $row['content']; ?></textarea>                                
                            <br>
                            <br>
                            <div class="pull-right" style="color:#cc0066; font-size: 15px;"><?php echo $row['date_sended']; ?></div>
                            
                            <div class="pull-left"> <span style="color:#cc0066; font-size: 20px;"> Sent by:</span><span style="color:solid gray; font-size: 20px;"> <?php echo $row['thename']; ?></span></div>

                            <br>
                            <br>

                            <div class="col col-12 text-center pb-3">
                                <a href="delete_message.php<?php echo '?id='.$id; ?>" class="btn btn-danger"><i class="fas fa-trash-alt"></i> Remove</a>
                            </div>
                        </div>
                    </div>
                    <?php } ?>
                </div>
            <?php }?>    
            <?php }?>        

            <!-- ------------------------#messages#---------------------------->
        </div>

    </section>

    <!--------------------------------- #Main section -------------------------------->
    
    <?php if ( 'report' == $action ) {
                        $studentID = $_REQUEST['id'];
                        $selectstudent = "SELECT * FROM students WHERE id='{$studentID}'";
                        $result = mysqli_query( $connection, $selectstudent );
                        $student = mysqli_fetch_assoc( $result );

                        $selectproo = "SELECT * FROM professors WHERE id='$sessionId'";
                        $result = mysqli_query( $connection, $selectproo );
                        $proo = mysqli_fetch_assoc( $result );

                        $selectdeg = "SELECT * FROM degrees WHERE id='{$studentID}'";
                        $result = mysqli_query( $connection, $selectdeg );
                        $deg = mysqli_fetch_assoc( $result );?>


                    <div class="addfaculty">
                        <div style="
                            max-width:700px;
                            margin:auto;
                            padding:20px;
                            border:1px solid #eee;
                            box-shadow:0 0 10px rgba(0, 0, 0, .15);
                            line-height:18px;
                            font-family:'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
                            color:#555;
                            margin-left: 500px;
                            ">                            
                            <form action="add.php" method="POST">
                                <div>
                                     <table cellpadding="0" cellspacing="0"style="width:100%;line-height:1.3;text-align:left;font-size:30px;">
                                           <tr>
                                             <td colspan="2">                                        
                                                 <table style="line-height:1.3;text-align:left;">
                                                      <tr>
                                                          <td style="font-size:17px;">

                                                              <span style="width: 100%;size: 100%;font-size: 30;color: #8B4513;font-weight: bold">
                                                              &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp Student Report
                                                              </span><br>
                                                              <b> Student Name: </b>  <?php echo $student['fname'];?><br>
                                                              <b> CGPA: </b>  <?php echo $student['CGPA'];?><br><br>
                                                              <b> Faculty Name: </b>  <?php echo $student['FacultyName'];?><br>
                                                              <b> Department Name: </b>  <?php echo $student['DepartmentName'];?><br>
                                                              <b> Academic Level: </b>Level  <?php echo $student['levelnumber'];?><br>
                                                              <b> Year: </b> 2020_2021<br>  
                                                              <b> Semester: </b> First Semester <br>
                                                              
                                                              <hr style="width:145%;height:3px;border-width:0;background-color:gray;">

                                                              <b style="background-color:#F8F8FF;width: 100%;size: 100%;font-size: 25;color: #A0522D"> Subject Details</b> <br><br>
                                                              <b> Title: </b>  <?php echo $proo['Subjects'];?><br>
                                                              <b> Code: </b>  <?php echo $proo['SubjectsCode'];?><br>
                                                              <b> Credit Hours Number: </b>  <?php echo $proo['chn'];?><br>
                                                              <b> Subject Professor Name: </b>  <?php echo $proo['fname'];?><br>
                                                              

                                                              <hr style="width:80%;height:3px;border-width:0;background-color:gray;margin-left: 155;">

                                                              <b style="background-color:#F8F8FF;width: 100%;size: 100%;font-size: 25;color: #A0522D"> Subject Degrees Details:</b><br><br>
                                                              <b> Assegnments: </b>  <?php echo $deg['Assegnments'];?><br>
                                                              <b> Mid-term Exam: </b>  <?php echo $deg['Mid'];?><br>
                                                              <b> Oral Exam: </b>  <?php echo $deg['Oral'];?><br>
                                                              <b> Practical Exam: </b>  <?php echo $deg['Practical'];?><br>                                   
                                                              <b> Final Exam: </b>  <?php echo $deg['Final'];?><br>


                                                          </td>
                                                      </tr>
                                                  </table>
                                              </td>
                                            </tr>
                                     </table>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php }?>


        <?php if ( 'reqprof' == $id ) 
        {
                        $selectreq = "SELECT * FROM req";
                        $result = mysqli_query( $connection, $selectreq );
                        while ( $req = mysqli_fetch_assoc( $result ) ) {?>

                    <div class="addreq">
                        <table>
                        <div class="main__form" style="width: 500;margin-left: 550">
                            <div class="main__form--title text-center"></div>
                            <form action="add.php" method="POST">
                                <div class="form-row">
                                    <div class="form-row">
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-user-circle"> </i>
                                            <input type="text" name="Name" readonly="" value="<?php echo $req['Name']; ?>" required>
                                        </label>
                                    </div>                                    
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-envelope"></i>
                                            <input type="email" name="Gmail" readonly="" value="<?php echo $req['Gmail']; ?>" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-phone-alt"></i>
                                            <input type="number" name="Phone" readonly="" value="<?php echo $req['Phone']; ?>" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-audio-description"></i>
                                            <input type="number" name="Age" readonly="" value="<?php echo $req['Age']; ?>" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="far fa-address-card"></i>
                                            <input type="text" name="Address" readonly="" value="<?php echo $req['Address']; ?>" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-graduation-cap"></i>
                                            <input type="text" name="Qualification" readonly="" value="<?php echo $req['Qualification']; ?>" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-book-open"></i>
                                            <input type="text" name="Subject" readonly="" value="<?php echo $req['Subject']; ?>" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fas fa-school"></i>
                                            <input type="text" name="faculty" readonly="" value="<?php echo $req['faculty']; ?>" required>
                                        </label>
                                    </div>
                                    <div class="col col-12">
                                        <label class="input">
                                            <i id="left" class="fa fa-list-alt"></i>
                                            <input type="text" name="department" readonly="" value="<?php echo $req['department']; ?>" required>
                                        </label>
                                    </div>
                                    <div>

                                        <script type="text/javascript">
                                            function checkbox1() 
                                            {
                                                alert("You Approving successfuly");
                                            }
                                        </script>

                                        <script type="text/javascript">
                                            function checkbox2() 
                                            {
                                                alert("You DisApproving successfuly");
                                            }
                                        </script>

                                        &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp

                                        <a id="left" onclick="checkbox1()" class="btn btn-success" style="background-color: #008CBA;color: #FFFAF0;font-weight: bold">
                                         Approve
                                        </a> 
                                        &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp

                                        <a  href="adminn.php?action=deletereq&id=<?php echo $req['id']; ?>" onclick="checkbox2()" class="btn btn-success" style="background-color: #008CBA;color: #FFFAF0;font-weight: bold">
                                         DisApprove
                                         </a>
                                     </div>
                                     </table>
                                    </div>
                                    <?php }?>
                            <?php }?>

        <?php if ( 'deletereq' == $action ) 
        {
            $reqID = $_REQUEST['id'];
            $deletereq = "DELETE FROM req WHERE id ='{$reqID}'";
            $result = mysqli_query( $connection, $deletereq );
            header( "location:adminn.php?id=reqprof" );
            ob_end_flush();
        }?>
                        

    <!-- Optional JavaScript -->
    <script src="assets/js/jquery-3.5.1.slim.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Custom Js -->
    <script src="./assets/js/app.js"></script>
</body>

</html>