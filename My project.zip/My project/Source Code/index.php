<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/login.css">
    
</head>

<body>

    <!--------------------------------- Main section -------------------------------->
    <section class="main">
        <div style="background: url(assets/img/123.jpg) no-repeat fixed;background-size: cover;position: absolute;width: 100%;height: 100%;">


            
            <div class="main__form--title text-center" ><span style="color: #F08080"> Log In </span></div>
            
                
                <form action="login_core.php" method="GET">
                   
                        &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                        &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                        &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                        &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                        &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                        &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp


                        <a href="adminn.php" class="btn btn-success" style="background-color: #FFFAF0;color: blue;font-weight: bold">
                            Admin
                        </a>

                        &nbsp&nbsp&nbsp&nbsp

                        <a href="adminpanel/admin/index.php" class="btn btn-success" style="background-color: #FFFAF0;color: blue;font-weight: bold">
                            Professor
                        </a>

                        &nbsp&nbsp&nbsp&nbsp

                        <a href="student.php" class="btn btn-success" style="background-color: #FFFAF0;color: blue;font-weight: bold">
                            Student
                        </a>

                        &nbsp&nbsp&nbsp&nbsp
                        

                            
                                

                                <script type="text/javascript">
                                    function checkbox() 
                                    {
                                     
                                      var yes = "Are you sure you want to continue?";
                                      var go = "Request.php";
                                      var message = "Action Was Cancelled By User";
                                     
                                      if (confirm(yes)) 
                                      {
                                     
                                          window.location = go;
                                     
                                      } 
                                      else 
                                      {
                                     
                                           alert(message);
                                     
                                      }
                                     
                                    }
                                </script>

                                <a href="request.php<?php echo '?id='.$id; ?>" onclick="checkbox()" class="btn btn-success" style="background-color: #FFFAF0;color: blue;font-weight: bold">
                                Sign Up Request As a Professor
                                </a>
                                
                            
                    
                        
                            <input type="hidden" name="action" value="login">
                            <?php if ( isset( $_REQUEST['error'] ) ) {
                                    echo "<h5 class='text-center' style='color:red;'>There are a false in your Email, Password or Role</h5>";
                            }?>
                        

                            <div>
                                <br>

                                <script type="text/javascript">
                                    function checkbox() 
                                    {
                                     
                                      var yes = "Are you sure you want to continue?";
                                      var go = "Request.php";
                                      var message = "Action Was Cancelled By User";
                                     
                                      if (confirm(yes)) 
                                      {
                                     
                                          window.location = go;
                                     
                                      } 
                                      else 
                                      {
                                     
                                           alert(message);
                                     
                                      }
                                     
                                    }
                                </script>

                                
                                
                            </div>
                    </div>
                </form>
            </div>
        </div>
    </section>

    <!--------------------------------- #Main section -------------------------------->



    <!-- Optional JavaScript -->
    <script src="assets/js/jquery-3.5.1.slim.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Custom Js -->
    <script src="./assets/js/app.js"></script>
</body>

</html>
