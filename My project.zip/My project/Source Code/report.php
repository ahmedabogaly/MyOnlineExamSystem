<?php
    session_start();
    $sessionId = $_SESSION['id'] ?? '';
    $sessionRole = $_SESSION['role'] ?? '';
    if ( $sessionId && $sessionRole ) {
        header( "location:index.php" );
        die();
    }

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/all.min.css">
    <style type="text/css">
    *,

body 
{
  background-color: #A9A9A9;
  font-family: "Raleway", sans-serif;
}

.main__form {
  position: absolute;
  width: 700px;
  padding: 5rem 3rem;
  -webkit-box-shadow: 0 0.5rem 2.75rem 0 white;
          box-shadow: 0 0.5rem 2.75rem 0 white;
  top: 70%;
  -webkit-transform: translate(-50%, -50%);
          transform: translate(-50%, -50%);
  left: 50%;
}

.main__form--title {
  font-size: 30px;
  font-weight: bold;
  padding: 9px 0;
  color: #483D8B;
}

.main__form .input {
  position: relative;
  display: block;
}

.main__form .input #left {
  color: #4e73df;
  border-color: #ccc;
  -webkit-transition: border-color 0.5s;
  transition: border-color 0.5s;
  left: 5px;
  padding-right: 3px;
  border-right-width: 1px;
  border-right-style: solid;
  position: absolute;
  top: 5px;
  width: 40px;
  height: 40px;
  font-size: 18px;
  line-height: 40px;
  text-align: center;
}

.main__form .input .right {
  color: #4e73df;
  border-color: #ccc;
  -webkit-transition: border-color 0.5s;
  transition: border-color 0.5s;
  right: 5px;
  padding-right: 3px;
  border-left-width: 1px;
  border-left-style: solid;
  position: absolute;
  top: 5px;
  width: 40px;
  height: 40px;
  cursor: pointer;
  font-size: 18px;
  line-height: 40px;
  text-align: center;
}

.main__form .input input,
.main__form .input select {
  padding-left: 50px !important;
  display: block;
  width: 100%;
  height: 50px !important;
  padding: 8px 10px;
  margin: 10px 0;
  outline: none;
  border: 2px solid #ccc;
  background: #f4f4f4;
  color: #384047;
  -webkit-appearance: normal;
     -moz-appearance: normal;
          appearance: normal;
  -webkit-transition: 0.5s ease;
  transition: 0.5s ease;
  color: #384047;
  font-weight: 500;
  letter-spacing: 1px;
}

.main__form .input input::-webkit-input-placeholder,
.main__form .input select::-webkit-input-placeholder {
  -webkit-transition: 0.5s ease;
  transition: 0.5s ease;
  color: #384047;
  font-weight: 500;
  letter-spacing: 1px;
}

.main__form .input input:-ms-input-placeholder,
.main__form .input select:-ms-input-placeholder {
  -webkit-transition: 0.5s ease;
  transition: 0.5s ease;
  color: #384047;
  font-weight: 500;
  letter-spacing: 1px;
}

.main__form .input input::-ms-input-placeholder,
.main__form .input select::-ms-input-placeholder {
  -webkit-transition: 0.5s ease;
  transition: 0.5s ease;
  color: #384047;
  font-weight: 500;
  letter-spacing: 1px;
}

.main__form .input input::placeholder,
.main__form .input select::placeholder {
  -webkit-transition: 0.5s ease;
  transition: 0.5s ease;
  color: #384047;
  font-weight: 500;
  letter-spacing: 1px;
}

.main__form .input input:focus, .main__form .input input:hover,
.main__form .input select:focus,
.main__form .input select:hover {
  border: 2px solid #36b9cc;
  -webkit-transition: all 0.5s ease;
  transition: all 0.5s ease;
  color: #384047;
  background-color: #f4f4f4;
  -webkit-box-shadow: inset 3px 5px 5px 0 rgba(0, 0, 0, 0.1);
          box-shadow: inset 3px 5px 5px 0 rgba(0, 0, 0, 0.1);
}

.main__form input[type="submit"] {
  width: 100%;
  letter-spacing: 1px;
  font-weight: bold;
  font-size: 20px;
  color: #fff;
  text-align: center;
  margin-top: 20px;
  padding: 14px 0;
  -webkit-transition: 0.5s ease;
  transition: 0.5s ease;
  border: 1px solid #4e73df;
  background-color: #4e73df;
}

.main__form input[type="submit"]:hover {
  color: #36b9cc;
  background-color: #fff;
  font-weight: 800;
  letter-spacing: 3px;
}
/*# sourceMappingURL=login.css.map */
</style>
    
</head>

<body>
                  <?php if ( 'report' == $action ) {
                        $studentID = $_REQUEST['id'];
                        $selectstudent = "SELECT * FROM students WHERE id='{$studentID}'";
                        $result = mysqli_query( $connection, $selectstudent );
                        $student = mysqli_fetch_assoc( $result );

                        $selectproo = "SELECT * FROM professors WHERE id='$sessionId'";
                        $result = mysqli_query( $connection, $selectproo );
                        $proo = mysqli_fetch_assoc( $result );

                        $selectdeg = "SELECT * FROM degrees WHERE id='{$studentID}'";
                        $result = mysqli_query( $connection, $selectdeg );
                        $deg = mysqli_fetch_assoc( $result );?>

                    <div class="addfaculty">
                        <div style="
                            max-width:700px;
                            margin:auto;
                            padding:20px;
                            border:1px solid #eee;
                            box-shadow:0 0 10px rgba(0, 0, 0, .15);
                            line-height:18px;
                            font-family:'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
                            color:#555;
                            margin-left: 500px;
                            ">                            
                            <form action="add.php" method="POST">
                                <div>
                                     <table cellpadding="0" cellspacing="0"style="width:100%;line-height:1.3;text-align:left;font-size:30px;">
                                           <tr>
                                             <td colspan="2">                                        
                                                 <table style="line-height:1.3;text-align:left;">
                                                      <tr>
                                                          <td style="font-size:17px;">

                                                              <span style="width: 100%;size: 100%;font-size: 30;color: #8B4513;font-weight: bold">
                                                              &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp Student Report
                                                              </span><br>
                                                              <b> Student Name: </b>  <?php echo $student['fname'];?><br>
                                                              <b> CGPA: </b>  <?php echo $student['CGPA'];?><br><br>
                                                              <b> Faculty Name: </b>  <?php echo $student['FacultyName'];?><br>
                                                              <b> Department Name: </b>  <?php echo $student['DepartmentName'];?><br>
                                                              <b> Academic Level: </b>Level  <?php echo $student['levelnumber'];?><br>
                                                              <b> Year: </b> 2020_2021<br>  
                                                              <b> Semester: </b> First Semester <br>
                                                              
                                                              <hr style="width:145%;height:3px;border-width:0;background-color:gray;">

                                                              <b style="background-color:#F8F8FF;width: 100%;size: 100%;font-size: 25;color: #A0522D"> Subject Details</b> <br><br>
                                                              <b> Title: </b>  <?php echo $proo['Subjects'];?><br>
                                                              <b> Code: </b>  <?php echo $proo['SubjectsCode'];?><br>
                                                              <b> Credit Hours Number: </b>  <?php echo $proo['chn'];?><br>
                                                              <b> Subject Professor Name: </b>  <?php echo $proo['fname'];?><br>
                                                              

                                                              <hr style="width:80%;height:3px;border-width:0;background-color:gray;margin-left: 155;">

                                                              <b style="background-color:#F8F8FF;width: 100%;size: 100%;font-size: 25;color: #A0522D"> Subject Degrees Details:</b><br><br>
                                                              <b> Assegnments: </b>  <?php echo $deg['Assegnments'];?><br>
                                                              <b> Mid-term Exam: </b>  <?php echo $deg['Mid'];?><br>
                                                              <b> Oral Exam: </b>  <?php echo $deg['Oral'];?><br>
                                                              <b> Practical Exam: </b>  <?php echo $deg['Practical'];?><br>                                   
                                                              <b> Final Exam: </b>  <?php echo $deg['Final'];?><br>


                                                          </td>
                                                      </tr>
                                                  </table>
                                              </td>
                                            </tr>
                                     </table>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php }?>

</body>

</html>
